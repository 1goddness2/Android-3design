package com.bifan.txtreaderlib.interfaces;

/**
 * Created by HP on 2017/11/15.
 */

public interface ITxtReaderLoggerListener {
    void onLog(String tag, String msg);
}
