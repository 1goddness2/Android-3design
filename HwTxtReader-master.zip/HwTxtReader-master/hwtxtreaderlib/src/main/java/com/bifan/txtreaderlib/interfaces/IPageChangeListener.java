package com.bifan.txtreaderlib.interfaces;

/**
 * Created by bifan-wei
 * on 2017/12/8.
 */

public interface IPageChangeListener {
    void onCurrentPage(float progress);
}
