package com.bifan.txtreaderlib.bean;

/*
* create by bifan-wei
* 2017-11-13
*/
public enum TxtMsg {
    InitError,
    FileNoExist,
}
